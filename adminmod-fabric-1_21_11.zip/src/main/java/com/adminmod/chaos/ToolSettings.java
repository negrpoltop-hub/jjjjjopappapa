package com.adminmod.chaos;

/** Прочие настройки админа. */
public final class ToolSettings {
    public int flySpeed = 1; // 1..10, 1 = обычная скорость полёта
    public int size = 0;     // индексы в таблицах Tools: размер, скорость ходьбы, здоровье, гравитация
    public int walk = 0;
    public int health = 0;
    public int gravity = 0;
}
