package com.adminmod.chaos;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Разрушение блоков по кнопке: шар/куб/цилиндр вокруг точки прицела и «разлом» — трещина вперёд.
 * Работа идёт очередью по несколько тысяч блоков за тик, чтобы сервер не зависал.
 * Последнее разрушение каждого админа можно откатить.
 */
public final class DestroyManager {
    /** На разрушение отводится не больше ~12 мс из 50 мс тика, поэтому TPS не проседает. */
    private static final long BUDGET_NANOS = 12_000_000L;
    private static final int MAX_CHANGES_PER_TICK = 8000;
    private static final int UNDO_LIMIT = 400_000;
    private static final int MAX_QUEUE = 6;

    /** Растущий массив позиций. */
    private static final class LongBuf {
        long[] data = new long[1024];
        int size = 0;

        void add(long value) {
            if (size == data.length) {
                data = java.util.Arrays.copyOf(data, size * 2);
            }
            data[size++] = value;
        }
    }

    /** Запись для отката: позиция и прежнее состояние блока. */
    private static final class Undo {
        final ServerWorld world;
        final LongBuf positions = new LongBuf();
        final List<BlockState> states = new ArrayList<>();

        Undo(ServerWorld world) {
            this.world = world;
        }
    }

    private static final class Job {
        final UUID owner;
        final ServerWorld world;
        final LongBuf targets;
        final boolean drops;
        final boolean fluids;
        final boolean bedrock;
        final Undo record;          // куда записывать прежние блоки (null при откате)
        final List<BlockState> restore; // что вернуть (только при откате)
        int index = 0;
        int changed = 0;

        Job(UUID owner, ServerWorld world, LongBuf targets, DestroySettings s, Undo record, List<BlockState> restore) {
            this.owner = owner;
            this.world = world;
            this.targets = targets;
            this.drops = s != null && s.drops;
            this.fluids = s == null || s.fluids;
            this.bedrock = s != null && s.bedrock;
            this.record = record;
            this.restore = restore;
        }
    }

    private static final Deque<Job> JOBS = new ArrayDeque<>();
    private static final Map<UUID, Undo> UNDO = new HashMap<>();

    private DestroyManager() {
    }

    public static void clear() {
        JOBS.clear();
        UNDO.clear();
    }

    /** Блок, на который смотрит игрок (до 100 блоков), иначе блок под ногами. */
    public static BlockPos targetBlock(ServerPlayerEntity player) {
        HitResult hit = player.raycast(100.0, 1.0f, false);
        if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult blockHit) {
            return blockHit.getBlockPos();
        }
        return player.getBlockPos();
    }

    // ---------- запуск ----------

    /** Разрушить фигуру вокруг точки прицела. @return сколько позиций поставлено в очередь, -1 если очередь полна */
    public static int blast(ServerPlayerEntity player, ServerWorld world, DestroySettings s) {
        if (JOBS.size() >= MAX_QUEUE) {
            return -1;
        }
        BlockPos c = targetBlock(player);
        int r = s.radius;
        LongBuf buf = new LongBuf();
        for (int y = c.getY() + r; y >= c.getY() - r; y--) {
            if (world.isOutOfHeightLimit(y)) {
                continue;
            }
            int dy = y - c.getY();
            for (int x = c.getX() - r; x <= c.getX() + r; x++) {
                int dx = x - c.getX();
                for (int z = c.getZ() - r; z <= c.getZ() + r; z++) {
                    int dz = z - c.getZ();
                    boolean inside = switch (s.shape) {
                        case 0 -> dx * dx + dy * dy + dz * dz <= r * r + r;
                        case 2 -> dx * dx + dz * dz <= r * r + r;
                        default -> true;
                    };
                    if (inside) {
                        buf.add(BlockPos.asLong(x, y, z));
                    }
                }
            }
        }
        enqueue(player.getUuid(), world, buf, s);
        return buf.size;
    }

    /** Разлом: неровная трещина вперёд от игрока, глубиной и шириной из настроек. */
    public static int rift(ServerPlayerEntity player, ServerWorld world, DestroySettings s) {
        if (JOBS.size() >= MAX_QUEUE) {
            return -1;
        }
        double yaw = Math.toRadians(player.getYaw());
        double dx = -Math.sin(yaw);
        double dz = Math.cos(yaw);
        double px = -dz;
        double pz = dx;
        BlockPos origin = player.getBlockPos();
        int floorY = origin.getY() - 1;
        int topY = origin.getY() + 10;

        // колонны разлома: ключ (x,z) -> нижняя отметка
        Map<Long, Integer> columns = new HashMap<>();
        for (double t = 2.0; t <= s.riftLength; t += 0.5) {
            double meander = Math.sin(t * 0.13) * s.riftRadius * 0.6;
            double w = Math.max(1.0, s.riftRadius * (0.8 + 0.2 * Math.sin(t * 0.37 + 1.0)));
            double cx = origin.getX() + 0.5 + dx * t + px * meander;
            double cz = origin.getZ() + 0.5 + dz * t + pz * meander;
            for (double o = -w; o <= w; o += 0.5) {
                double f = Math.abs(o) / (w + 1.0);
                int depth = (int) Math.round(s.riftDepth * (1.0 - f * f));
                int x = (int) Math.floor(cx + px * o);
                int z = (int) Math.floor(cz + pz * o);
                columns.merge(BlockPos.asLong(x, 0, z), floorY - depth, Math::min);
            }
        }

        // ближние колонны первыми: разлом «раскрывается» от игрока вперёд
        List<Map.Entry<Long, Integer>> sorted = new ArrayList<>(columns.entrySet());
        sorted.sort(Comparator.comparingDouble(e -> {
            BlockPos p = BlockPos.fromLong(e.getKey());
            double ddx = p.getX() - origin.getX();
            double ddz = p.getZ() - origin.getZ();
            return ddx * ddx + ddz * ddz;
        }));

        LongBuf buf = new LongBuf();
        for (Map.Entry<Long, Integer> e : sorted) {
            BlockPos column = BlockPos.fromLong(e.getKey());
            for (int y = topY; y >= e.getValue(); y--) {
                if (!world.isOutOfHeightLimit(y)) {
                    buf.add(BlockPos.asLong(column.getX(), y, column.getZ()));
                }
            }
        }
        enqueue(player.getUuid(), world, buf, s);
        return buf.size;
    }

    private static void enqueue(UUID owner, ServerWorld world, LongBuf buf, DestroySettings s) {
        Undo record = new Undo(world);
        UNDO.put(owner, record);
        JOBS.add(new Job(owner, world, buf, s, record, null));
    }

    /** Вернуть блоки последнего разрушения. @return сколько блоков будет возвращено, 0 если откатывать нечего */
    public static int undo(UUID owner) {
        Undo record = UNDO.remove(owner);
        if (record == null || record.positions.size == 0 || JOBS.size() >= MAX_QUEUE) {
            return 0;
        }
        JOBS.add(new Job(owner, record.world, record.positions, null, null, record.states));
        return record.positions.size;
    }

    /** Отменить все ещё не выполненные разрушения этого админа. @return сколько задач отменено */
    public static int cancel(UUID owner) {
        int before = JOBS.size();
        JOBS.removeIf(job -> job.owner.equals(owner));
        return before - JOBS.size();
    }

    // ---------- работа по тикам ----------

    public static void tick() {
        Job job = JOBS.peek();
        if (job == null) {
            return;
        }
        ServerWorld world = job.world;
        long deadline = System.nanoTime() + BUDGET_NANOS;
        int iterations = 0;
        int changes = 0;
        long lastChunk = Long.MIN_VALUE;
        boolean lastLoaded = false;
        while (job.index < job.targets.size && changes < MAX_CHANGES_PER_TICK) {
            if ((++iterations & 63) == 0 && System.nanoTime() > deadline) {
                break;
            }
            int i = job.index++;
            long packed = job.targets.data[i];
            BlockPos pos = BlockPos.fromLong(packed);

            // проверку загруженности чанка запоминаем: соседние блоки почти всегда в одном чанке
            long chunk = ((long) (pos.getX() >> 4) << 32) ^ ((pos.getZ() >> 4) & 0xFFFFFFFFL);
            if (chunk != lastChunk) {
                lastChunk = chunk;
                lastLoaded = world.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4);
            }
            if (!lastLoaded) {
                continue;
            }
            if (job.restore != null) {
                world.setBlockState(pos, job.restore.get(i), Block.NOTIFY_ALL);
                job.changed++;
                changes++;
                continue;
            }

            BlockState state = world.getBlockState(pos);
            if (state.isAir()) {
                continue;
            }
            if (!job.fluids && state.getBlock() instanceof FluidBlock) {
                continue;
            }
            if (!job.bedrock && state.getHardness(world, pos) < 0) {
                continue;
            }
            if (job.record != null && job.record.positions.size < UNDO_LIMIT) {
                job.record.positions.add(packed);
                job.record.states.add(state);
            }
            if (job.drops) {
                world.breakBlock(pos, true);
            } else {
                world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL | Block.SKIP_DROPS);
            }
            job.changed++;
            changes++;
        }

        if (job.index >= job.targets.size) {
            JOBS.poll();
            ServerPlayerEntity owner = world.getServer().getPlayerManager().getPlayer(job.owner);
            if (owner != null) {
                String text = job.restore != null ? "Возвращено блоков: " : "Разрушено блоков: ";
                owner.sendMessage(Text.literal(text + job.changed), true);
            }
        }
    }
}
