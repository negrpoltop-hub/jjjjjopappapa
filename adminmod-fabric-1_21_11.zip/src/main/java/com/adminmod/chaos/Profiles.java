package com.adminmod.chaos;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Настройки хранятся в памяти, пока сервер работает. */
public final class Profiles {
    private static final Map<UUID, MeteorSettings> METEORS = new HashMap<>();
    private static final Map<UUID, BombSettings> BOMBS = new HashMap<>();
    private static final Map<UUID, DestroySettings> DESTROYS = new HashMap<>();
    private static final Map<UUID, ToolSettings> TOOLS = new HashMap<>();

    private Profiles() {
    }

    public static MeteorSettings meteor(UUID id) {
        return METEORS.computeIfAbsent(id, key -> new MeteorSettings());
    }

    public static BombSettings bomb(UUID id) {
        return BOMBS.computeIfAbsent(id, key -> new BombSettings());
    }

    public static DestroySettings destroy(UUID id) {
        return DESTROYS.computeIfAbsent(id, key -> new DestroySettings());
    }

    public static ToolSettings tools(UUID id) {
        return TOOLS.computeIfAbsent(id, key -> new ToolSettings());
    }
}
