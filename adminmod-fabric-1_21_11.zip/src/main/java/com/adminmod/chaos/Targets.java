package com.adminmod.chaos;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class Targets {
    private Targets() {
    }

    /** Точка, на которую смотрит игрок (до 100 блоков), иначе позиция игрока. */
    public static Vec3d look(ServerPlayerEntity player) {
        HitResult hit = player.raycast(100.0, 1.0f, false);
        if (hit.getType() == HitResult.Type.BLOCK) {
            return hit.getPos();
        }
        return Vec3d.ofCenter(player.getBlockPos());
    }

    /** Загружен ли чанк с этой позицией (чтобы не грузить и не генерировать чанки зря). */
    public static boolean loaded(ServerWorld world, net.minecraft.util.math.BlockPos pos) {
        return world.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4);
    }

    public static void explode(ServerWorld world, Vec3d pos, double power, boolean fire, boolean breakBlocks) {
        world.createExplosion(null, pos.x, pos.y, pos.z, (float) power, fire,
                breakBlocks ? World.ExplosionSourceType.TNT : World.ExplosionSourceType.NONE);
    }
}
