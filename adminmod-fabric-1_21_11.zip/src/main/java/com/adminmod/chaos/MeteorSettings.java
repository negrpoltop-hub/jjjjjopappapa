package com.adminmod.chaos;

/** Настройки метеоритного дождя (у каждого админа свои). */
public final class MeteorSettings {
    public int count = 20;          // сколько метеоритов
    public int radius = 20;         // радиус области падения
    public int height = 40;         // высота появления над целью
    public int interval = 5;        // тиков между метеоритами
    public double power = 3.0;      // сила взрыва
    public double speed = 1.5;      // скорость падения, блоков/тик
    public boolean fire = false;    // поджигать
    public boolean breakBlocks = true; // ломать блоки

    public MeteorSettings copy() {
        MeteorSettings c = new MeteorSettings();
        c.count = count;
        c.radius = radius;
        c.height = height;
        c.interval = interval;
        c.power = power;
        c.speed = speed;
        c.fire = fire;
        c.breakBlocks = breakBlocks;
        return c;
    }
}
