package com.adminmod.chaos;

import com.adminmod.Config;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Бомба из руки: правый клик «Жезлом бомб» запускает бомбу туда, куда вы смотрите. */
public final class BombManager {
    public static final String WAND_NAME = "Жезл бомб";
    private static final int MAX_AGE = 200;
    private static final int MAX_BOMBS = 300;

    private static final class Bomb {
        final ServerWorld world;
        final UUID owner;
        final BombSettings settings;
        Vec3d pos;
        Vec3d vel;
        int age = 0;

        Bomb(ServerWorld world, UUID owner, Vec3d pos, Vec3d vel, BombSettings settings) {
            this.world = world;
            this.owner = owner;
            this.pos = pos;
            this.vel = vel;
            this.settings = settings;
        }
    }

    private static final List<Bomb> BOMBS = new ArrayList<>();
    private static final Map<UUID, Long> LAST_SHOT = new HashMap<>();

    private BombManager() {
    }

    public static void clear() {
        BOMBS.clear();
        LAST_SHOT.clear();
    }

    public static void giveWand(ServerPlayerEntity player) {
        ItemStack wand = new ItemStack(Items.BLAZE_ROD);
        wand.set(DataComponentTypes.CUSTOM_NAME, Text.literal(WAND_NAME).styled(style -> style.withItalic(false)));
        wand.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        player.getInventory().offerOrDrop(wand);
    }

    private static boolean isWand(ItemStack stack) {
        if (!stack.isOf(Items.BLAZE_ROD)) {
            return false;
        }
        Text name = stack.get(DataComponentTypes.CUSTOM_NAME);
        return name != null && WAND_NAME.equals(name.getString());
    }

    /** Обработчик правого клика предметом (UseItemCallback). */
    public static ActionResult onUse(PlayerEntity player, World world, Hand hand) {
        if (!(player instanceof ServerPlayerEntity serverPlayer) || !(world instanceof ServerWorld serverWorld)) {
            return ActionResult.PASS;
        }
        if (!isWand(player.getStackInHand(hand)) || !Config.isAdmin(serverPlayer)) {
            return ActionResult.PASS;
        }
        BombSettings settings = Profiles.bomb(serverPlayer.getUuid());
        if (!settings.enabled) {
            return ActionResult.PASS;
        }
        long now = serverWorld.getTime();
        Long last = LAST_SHOT.get(serverPlayer.getUuid());
        if (last != null && now - last < settings.cooldown) {
            return ActionResult.SUCCESS;
        }
        LAST_SHOT.put(serverPlayer.getUuid(), now);
        launch(serverWorld, serverPlayer, settings);
        return ActionResult.SUCCESS;
    }

    private static void launch(ServerWorld world, ServerPlayerEntity player, BombSettings s) {
        Vec3d look = player.getRotationVec(1.0f);
        Vec3d origin = player.getEyePos().add(look.multiply(1.0));
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int i = 0; i < s.count && BOMBS.size() < MAX_BOMBS; i++) {
            Vec3d dir = look;
            if (s.spread > 0 && s.count > 1) {
                dir = look.add(
                        (random.nextDouble() - 0.5) * 2 * s.spread,
                        (random.nextDouble() - 0.5) * 2 * s.spread,
                        (random.nextDouble() - 0.5) * 2 * s.spread).normalize();
            }
            BOMBS.add(new Bomb(world, player.getUuid(), origin, dir.multiply(s.speed), s.copy()));
        }
    }

    public static void tick() {
        Iterator<Bomb> iterator = BOMBS.iterator();
        while (iterator.hasNext()) {
            if (step(iterator.next())) {
                iterator.remove();
            }
        }
    }

    /** @return true, если бомба взорвалась или пропала */
    private static boolean step(Bomb b) {
        b.age++;
        b.vel = b.vel.add(0, -b.settings.gravity, 0);
        int sub = (int) Math.max(1, Math.ceil(b.vel.length() / 0.5));
        Vec3d stepVec = b.vel.multiply(1.0 / sub);
        // существа вдоль пути за тик ищем один раз, а не на каждом под-шаге
        Box sweep = new Box(b.pos, b.pos.add(b.vel)).expand(1.0);
        List<Entity> candidates = b.world.getOtherEntities(null, sweep,
                entity -> entity instanceof LivingEntity && entity.isAlive() && !entity.getUuid().equals(b.owner));
        for (int i = 0; i < sub; i++) {
            b.pos = b.pos.add(stepVec);
            if (b.pos.y < b.world.getBottomY()) {
                return true;
            }
            BlockPos blockPos = BlockPos.ofFloored(b.pos);
            if (!Targets.loaded(b.world, blockPos)) {
                return true;
            }
            boolean hitBlock = !b.world.getBlockState(blockPos).isAir();
            boolean hitMob = false;
            if (!hitBlock) {
                for (Entity entity : candidates) {
                    if (entity.getBoundingBox().expand(0.5).contains(b.pos)) {
                        hitMob = true;
                        break;
                    }
                }
            }
            if (hitBlock || hitMob) {
                explode(b);
                return true;
            }
        }
        b.world.spawnParticles(ParticleTypes.FLAME, b.pos.x, b.pos.y, b.pos.z, 4, 0.1, 0.1, 0.1, 0.01);
        b.world.spawnParticles(ParticleTypes.SMOKE, b.pos.x, b.pos.y, b.pos.z, 2, 0.1, 0.1, 0.1, 0.0);
        if (b.age >= MAX_AGE) {
            explode(b);
            return true;
        }
        return false;
    }

    private static void explode(Bomb b) {
        Targets.explode(b.world, b.pos, b.settings.power, b.settings.fire, b.settings.breakBlocks);
    }
}
