package com.adminmod.chaos;

/** Настройки разрушения блоков и разлома (у каждого админа свои). */
public final class DestroySettings {
    public static final String[] SHAPES = {"шар", "куб", "цилиндр"};

    public int radius = 5;          // радиус разрушения вокруг точки прицела
    public int shape = 0;           // 0 шар, 1 куб, 2 цилиндр
    public int riftRadius = 3;      // радиус (ширина) разлома
    public int riftLength = 40;     // длина разлома вперёд
    public int riftDepth = 20;      // глубина разлома
    public boolean drops = false;   // выбрасывать предметы из блоков
    public boolean fluids = true;   // убирать воду и лаву
    public boolean bedrock = false; // ломать неразрушимые блоки (бедрок и т.п.)
}
