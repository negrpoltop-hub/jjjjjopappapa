package com.adminmod;

import com.adminmod.chaos.BombManager;
import com.adminmod.chaos.DestroyManager;
import com.adminmod.chaos.MeteorManager;
import com.adminmod.npc.NpcManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.world.ServerWorld;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AdminMod implements ModInitializer {
    public static final String ID = "adminmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);

    @Override
    public void onInitialize() {
        Config.load();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                ModuleManager.registerCommands(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            MeteorManager.tick();
            BombManager.tick();
            DestroyManager.tick();
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            MeteorManager.clear();
            BombManager.clear();
            DestroyManager.clear();
            NpcManager.clear();
        });
        // горячая клавиша Ctrl+Shift+Ц на клиенте -> открыть панель (только админам)
        PayloadTypeRegistry.playC2S().register(OpenPanelPayload.ID, OpenPanelPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(OpenPanelPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            context.server().execute(() -> {
                if (!Config.isAdmin(player)) {
                    return;
                }
                ServerWorld world = Tools.worldOf(context.server(), player);
                if (world != null) {
                    PanelHandler.open(player, context.server(), world);
                }
            });
        });
        UseItemCallback.EVENT.register(BombManager::onUse);
        UseEntityCallback.EVENT.register(NpcManager::onUse);
        LOGGER.info("Admin Mod loaded");
    }

    /** Команду может выполнить только игрок из списка admins в конфиге. */
    public static boolean isAdminSource(ServerCommandSource source) {
        return source.getEntity() instanceof ServerPlayerEntity player && Config.isAdmin(player);
    }
}
