package com.adminmod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Пакет «открыть админ-панель»: клиент отправляет его по горячей клавише Ctrl+Shift+Ц. */
public record OpenPanelPayload() implements CustomPayload {
    public static final CustomPayload.Id<OpenPanelPayload> ID =
            new CustomPayload.Id<>(Identifier.of(AdminMod.ID, "open_panel"));
    public static final PacketCodec<RegistryByteBuf, OpenPanelPayload> CODEC =
            PacketCodec.unit(new OpenPanelPayload());

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
