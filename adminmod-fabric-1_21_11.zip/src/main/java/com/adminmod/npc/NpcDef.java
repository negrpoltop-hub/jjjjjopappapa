package com.adminmod.npc;

import java.util.LinkedHashMap;
import java.util.Map;

/** Описание НПС-раздатчика. Хранится в config/adminmod.json по UUID сущности. */
public final class NpcDef {
    public String name = "Раздатчик";
    public String item = "minecraft:diamond_sword";
    public int count = 1;
    /** Перезарядка для каждого игрока, секунды (0 = без перезарядки). */
    public int cooldown = 0;
    /** id зачарования -> уровень. */
    public Map<String, Integer> enchants = new LinkedHashMap<>();
}
