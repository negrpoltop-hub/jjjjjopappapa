package com.adminmod;

import com.adminmod.modules.BuildModule;
import com.adminmod.modules.ChaosModule;
import com.adminmod.modules.CoreModule;
import com.adminmod.modules.ItemModule;
import com.adminmod.modules.NpcModule;
import com.adminmod.modules.PanelModule;
import com.adminmod.modules.PlayerModule;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.ServerCommandSource;

import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = List.of(
            new CoreModule(),
            new PanelModule(),
            new PlayerModule(),
            new ItemModule(),
            new ChaosModule(),
            new BuildModule(),
            new NpcModule()
    );

    private ModuleManager() {
    }

    public static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        for (Module module : MODULES) {
            if (Config.get().disabledModules.contains(module.id())) {
                continue;
            }
            module.registerCommands(dispatcher);
        }
    }
}
