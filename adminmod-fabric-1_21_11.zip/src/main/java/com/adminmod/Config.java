package com.adminmod;

import com.adminmod.npc.NpcDef;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.network.ServerPlayerEntity;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Config {
    /** Ники админов (без учёта регистра). */
    public List<String> admins = new ArrayList<>();
    /** Уровень зачарования по умолчанию: 0 = ванильный максимум каждого чара, 1..255 = ровно этот уровень. */
    public int defaultEnchantLevel = 0;
    /** НПС-раздатчики: UUID сущности -> что выдаёт. Заполняется автоматически. */
    public Map<String, NpcDef> npcs = new HashMap<>();
    /** id модулей, которые нужно отключить. */
    public Set<String> disabledModules = new HashSet<>();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config instance = new Config();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("adminmod.json");
    }

    public static Config get() {
        return instance;
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Config loaded = GSON.fromJson(Files.readString(p), Config.class);
                if (loaded != null) {
                    instance = loaded;
                }
            }
            save();
        } catch (Exception e) {
            AdminMod.LOGGER.error("Не удалось загрузить конфиг", e);
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (IOException e) {
            AdminMod.LOGGER.error("Не удалось сохранить конфиг", e);
        }
    }

    public static boolean isAdmin(ServerPlayerEntity player) {
        String name = player.getName().getString();
        for (String admin : instance.admins) {
            if (admin.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }
}
