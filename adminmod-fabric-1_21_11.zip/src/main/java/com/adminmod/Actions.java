package com.adminmod;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.List;

/** Общие действия: их используют и команды, и админ-панель. */
public final class Actions {
    private Actions() {
    }

    public static void heal(ServerPlayerEntity player) {
        player.setHealth(player.getMaxHealth());
        player.extinguish();
    }

    public static void feed(ServerPlayerEntity player) {
        player.getHungerManager().add(20, 1.0f);
    }

    /** @return true, если полёт теперь включён */
    public static boolean toggleFly(ServerPlayerEntity player) {
        PlayerAbilities abilities = player.getAbilities();
        abilities.allowFlying = !abilities.allowFlying;
        if (!abilities.allowFlying) {
            abilities.flying = false;
        }
        player.sendAbilitiesUpdate();
        return abilities.allowFlying;
    }

    /** @return true, если бессмертие теперь включено */
    public static boolean toggleGod(ServerPlayerEntity player) {
        boolean value = !player.isInvulnerable();
        player.setInvulnerable(value);
        return value;
    }

    public static boolean repair(ItemStack stack) {
        if (stack.isEmpty() || !stack.isDamageable()) {
            return false;
        }
        stack.setDamage(0);
        return true;
    }

    /** Включает/выключает бесконечный эффект. @return true, если эффект теперь включён */
    public static boolean toggleEffect(ServerPlayerEntity player, RegistryEntry<StatusEffect> effect, int amplifier) {
        if (player.hasStatusEffect(effect)) {
            player.removeStatusEffect(effect);
            return false;
        }
        player.addStatusEffect(new StatusEffectInstance(effect, StatusEffectInstance.INFINITE, amplifier, false, false));
        return true;
    }

    public static void clearEffects(ServerPlayerEntity player) {
        player.clearStatusEffects();
    }

    /** Молния в 4 блоках перед игроком. */
    public static void smite(ServerWorld world, ServerPlayerEntity player) {
        BlockPos pos = player.getBlockPos().offset(player.getHorizontalFacing(), 4);
        EntityType.LIGHTNING_BOLT.spawn(world, pos, SpawnReason.COMMAND);
    }

    /** Убирает враждебных мобов в радиусе 32 блоков. @return сколько убрано */
    public static int clearMobs(ServerWorld world, ServerPlayerEntity player) {
        Box box = player.getBoundingBox().expand(32.0);
        List<HostileEntity> mobs = world.getEntitiesByClass(HostileEntity.class, box, mob -> true);
        for (HostileEntity mob : mobs) {
            mob.discard();
        }
        return mobs.size();
    }

    /**
     * Ставит на предмет все подходящие зачарования.
     * level = 0 -> ванильный максимум каждого чара; 1..255 -> ровно этот уровень.
     * Конфликтующие (Острота + Небесная кара) и проклятия пропускаются.
     *
     * @return сколько зачарований наложено
     */
    public static int enchantMax(MinecraftServer server, ItemStack stack, int level) {
        Registry<Enchantment> registry = server.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        int chosen = Math.max(0, Math.min(255, level));

        List<RegistryEntry.Reference<Enchantment>> all = registry.streamEntries().toList();
        List<RegistryEntry.Reference<Enchantment>> applied = new ArrayList<>();

        for (RegistryEntry.Reference<Enchantment> entry : all) {
            Enchantment enchantment = entry.value();
            String path = entry.getKey().map(key -> key.getValue().getPath()).orElse("");
            if (path.contains("curse")) {
                continue;
            }
            if (!enchantment.isAcceptableItem(stack)) {
                continue;
            }
            boolean conflict = false;
            for (RegistryEntry.Reference<Enchantment> other : applied) {
                if (enchantment.exclusiveSet().contains(other)) {
                    conflict = true;
                    break;
                }
            }
            if (conflict) {
                continue;
            }
            int applyLevel = chosen == 0 ? enchantment.getMaxLevel() : chosen;
            stack.addEnchantment(entry, applyLevel);
            applied.add(entry);
        }
        return applied.size();
    }
}
