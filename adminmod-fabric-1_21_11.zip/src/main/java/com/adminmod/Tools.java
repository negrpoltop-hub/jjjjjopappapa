package com.adminmod;

import com.adminmod.chaos.Targets;
import com.adminmod.chaos.ToolSettings;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import net.minecraft.world.Heightmap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Дополнительные инструменты админа: телепорты, полёт, погода, предметы, мобы. Используются командами и панелью. */
public final class Tools {
    private Tools() {
    }

    private static final Map<UUID, Vec3d> BACK = new HashMap<>();

    /** Мир, в котором сейчас находится игрок (не зависит от версии маппингов). */
    public static ServerWorld worldOf(MinecraftServer server, ServerPlayerEntity player) {
        for (ServerWorld world : server.getWorlds()) {
            if (world.getPlayerByUuid(player.getUuid()) != null) {
                return world;
            }
        }
        return null;
    }

    // ---------- полёт ----------

    /** Скорость полёта 1..10 (1 = обычная). Включает возможность летать. */
    public static void setFlySpeed(ServerPlayerEntity player, int level) {
        PlayerAbilities abilities = player.getAbilities();
        abilities.setFlySpeed(0.05f * Math.max(1, Math.min(10, level)));
        player.sendAbilitiesUpdate();
    }

    // ---------- перемещение ----------

    private static void remember(ServerPlayerEntity player) {
        BACK.put(player.getUuid(), new Vec3d(player.getX(), player.getY(), player.getZ()));
    }

    /** Телепорт на блок, на который смотрит игрок. @return false, если смотрит в пустоту */
    public static boolean teleportToTarget(ServerPlayerEntity player) {
        HitResult hit = player.raycast(200.0, 1.0f, false);
        if (hit.getType() != HitResult.Type.BLOCK || !(hit instanceof BlockHitResult blockHit)) {
            return false;
        }
        BlockPos pos = blockHit.getBlockPos().up();
        remember(player);
        player.requestTeleport(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        return true;
    }

    /** Телепорт на поверхность над собой. */
    public static void teleportToSurface(ServerWorld world, ServerPlayerEntity player) {
        int x = player.getBlockPos().getX();
        int z = player.getBlockPos().getZ();
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        remember(player);
        player.requestTeleport(x + 0.5, y, z + 0.5);
    }

    /** Вернуться на место перед последним телепортом. */
    public static boolean teleportBack(ServerPlayerEntity player) {
        Vec3d back = BACK.get(player.getUuid());
        if (back == null) {
            return false;
        }
        remember(player);
        player.requestTeleport(back.x, back.y, back.z);
        return true;
    }

    // ---------- режим игры ----------

    public static String cycleGameMode(ServerPlayerEntity player) {
        GameMode current = player.interactionManager.getGameMode();
        GameMode next;
        String name;
        if (current == GameMode.SURVIVAL) {
            next = GameMode.CREATIVE;
            name = "креатив";
        } else if (current == GameMode.CREATIVE) {
            next = GameMode.SPECTATOR;
            name = "наблюдатель";
        } else if (current == GameMode.SPECTATOR) {
            next = GameMode.ADVENTURE;
            name = "приключение";
        } else {
            next = GameMode.SURVIVAL;
            name = "выживание";
        }
        player.changeGameMode(next);
        return name;
    }

    // ---------- мир ----------

    /** Выполняет обычную команду от имени сервера (время, погода). */
    public static void run(MinecraftServer server, String command) {
        server.getCommandManager().executeWithPrefix(server.getCommandSource(), command);
    }

    /** Несколько молний вокруг точки прицела. */
    public static void lightningStorm(ServerWorld world, ServerPlayerEntity player) {
        Vec3d center = Targets.look(player);
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int i = 0; i < 14; i++) {
            int x = (int) Math.floor(center.x + (random.nextDouble() * 2 - 1) * 12);
            int z = (int) Math.floor(center.z + (random.nextDouble() * 2 - 1) * 12);
            int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
            EntityType.LIGHTNING_BOLT.spawn(world, new BlockPos(x, y, z), SpawnReason.COMMAND);
        }
    }

    /** Мощный взрыв в точке прицела. */
    public static void megaExplosion(ServerWorld world, ServerPlayerEntity player) {
        Targets.explode(world, Targets.look(player), 10.0, false, true);
    }

    // ---------- предметы и мобы ----------

    /** Убирает предметы на земле в радиусе 64 блоков. @return сколько убрано */
    public static int clearItems(ServerWorld world, ServerPlayerEntity player) {
        Box box = player.getBoundingBox().expand(64.0);
        List<ItemEntity> items = world.getEntitiesByClass(ItemEntity.class, box, item -> true);
        for (ItemEntity item : items) {
            item.discard();
        }
        return items.size();
    }

    /** Притягивает предметы с земли (радиус 24) к игроку. @return сколько притянуто */
    public static int magnet(ServerWorld world, ServerPlayerEntity player) {
        Box box = player.getBoundingBox().expand(24.0);
        List<ItemEntity> items = world.getEntitiesByClass(ItemEntity.class, box, item -> true);
        for (ItemEntity item : items) {
            item.setPosition(player.getX(), player.getY(), player.getZ());
        }
        return items.size();
    }

    /** Замораживает/размораживает мобов в радиусе 32 (НПС-раздатчики не трогает). @return сколько мобов затронуто */
    public static int freezeMobs(ServerWorld world, ServerPlayerEntity player, boolean freeze) {
        Box box = player.getBoundingBox().expand(32.0);
        List<MobEntity> mobs = world.getEntitiesByClass(MobEntity.class, box,
                mob -> !Config.get().npcs.containsKey(mob.getUuidAsString()));
        for (MobEntity mob : mobs) {
            mob.setAiDisabled(freeze);
        }
        return mobs.size();
    }

    /** Вылечить и накормить всех игроков онлайн. */
    public static int healAll(MinecraftServer server) {
        List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();
        for (ServerPlayerEntity p : players) {
            Actions.heal(p);
            Actions.feed(p);
        }
        return players.size();
    }

    /** Эндер-сундук где угодно. */
    public static void openEnderChest(ServerPlayerEntity player) {
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, inventory, p) -> GenericContainerScreenHandler.createGeneric9x3(
                        syncId, inventory, player.getEnderChestInventory()),
                Text.literal("Эндер-сундук")));
    }

    /** Выдаёт набор админа: незеритовое снаряжение с зачарованиями. @return сколько предметов выдано */
    public static int giveKit(MinecraftServer server, ServerPlayerEntity player, int level) {
        net.minecraft.item.Item[] kit = {
                Items.NETHERITE_SWORD, Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE, Items.NETHERITE_SHOVEL,
                Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
                Items.ELYTRA, Items.BOW
        };
        for (net.minecraft.item.Item item : kit) {
            ItemStack stack = new ItemStack(item);
            Actions.enchantMax(server, stack, level);
            player.getInventory().offerOrDrop(stack);
        }
        player.getInventory().offerOrDrop(new ItemStack(Items.GOLDEN_CARROT, 64));
        player.getInventory().offerOrDrop(new ItemStack(Items.FIREWORK_ROCKET, 64));
        return kit.length + 2;
    }

    // ---------- строительство ----------

    private static boolean replaceable(ServerWorld world, BlockPos pos) {
        var state = world.getBlockState(pos);
        return state.isAir() || state.getBlock() instanceof FluidBlock;
    }

    /** Каменная платформа 11x11 под ногами (занимает только воздух и жидкости). @return блоков поставлено */
    public static int buildPlatform(ServerWorld world, ServerPlayerEntity player) {
        BlockPos center = player.getBlockPos().down();
        int placed = 0;
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                BlockPos pos = center.add(dx, 0, dz);
                if (!world.isOutOfHeightLimit(pos) && replaceable(world, pos)) {
                    world.setBlockState(pos, Blocks.STONE_BRICKS.getDefaultState());
                    placed++;
                }
            }
        }
        return placed;
    }

    /** Бункер 7x7: стеклянные стены, каменный пол и потолок, лампа, внутри пусто. @return блоков изменено */
    public static int buildBunker(ServerWorld world, ServerPlayerEntity player) {
        BlockPos base = player.getBlockPos();
        int changed = 0;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = -1; dy <= 4; dy++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    if (world.isOutOfHeightLimit(pos)) {
                        continue;
                    }
                    boolean wall = Math.abs(dx) == 3 || Math.abs(dz) == 3;
                    net.minecraft.block.BlockState state;
                    if (dy == -1) {
                        state = Blocks.STONE_BRICKS.getDefaultState();
                    } else if (dy == 4) {
                        state = (dx == 0 && dz == 0) ? Blocks.SEA_LANTERN.getDefaultState()
                                : Blocks.STONE_BRICKS.getDefaultState();
                    } else if (wall) {
                        state = Blocks.GLASS.getDefaultState();
                    } else {
                        state = Blocks.AIR.getDefaultState();
                    }
                    world.setBlockState(pos, state);
                    changed++;
                }
            }
        }
        return changed;
    }

    /** Выдаёт набор строителя. @return сколько видов предметов выдано */
    public static int giveBuilderKit(ServerPlayerEntity player) {
        net.minecraft.item.Item[] items = {
                Items.STONE_BRICKS, Items.COBBLESTONE, Items.OAK_PLANKS, Items.GLASS, Items.TORCH,
                Items.LADDER, Items.SCAFFOLDING, Items.OBSIDIAN, Items.WATER_BUCKET
        };
        for (net.minecraft.item.Item item : items) {
            player.getInventory().offerOrDrop(new ItemStack(item, item.getMaxCount()));
        }
        return items.length;
    }

    // ---------- прочее ----------

    /** Призывает четырёх железных големов-охранников вокруг игрока. @return сколько вызвано */
    public static int summonGuards(ServerWorld world, ServerPlayerEntity player) {
        int[][] offsets = {{2, 2}, {-2, 2}, {2, -2}, {-2, -2}};
        int count = 0;
        for (int[] o : offsets) {
            if (EntityType.IRON_GOLEM.spawn(world, player.getBlockPos().add(o[0], 0, o[1]), SpawnReason.COMMAND) != null) {
                count++;
            }
        }
        return count;
    }

    /** Копия предмета из руки (полный стак) в инвентарь. */
    public static boolean duplicateHeld(ServerPlayerEntity player) {
        ItemStack held = player.getMainHandStack();
        if (held.isEmpty()) {
            return false;
        }
        ItemStack copy = held.copy();
        copy.setCount(copy.getMaxCount());
        player.getInventory().offerOrDrop(copy);
        return true;
    }

    /** Чинит все предметы в инвентаре. @return сколько починено */
    public static int repairAll(ServerPlayerEntity player) {
        PlayerInventory inventory = player.getInventory();
        int count = 0;
        for (int i = 0; i < inventory.size(); i++) {
            if (Actions.repair(inventory.getStack(i))) {
                count++;
            }
        }
        return count;
    }

    /** Телепортирует всех игроков к админу (обычной командой /tp). */
    public static void bringAll(MinecraftServer server, ServerPlayerEntity player) {
        run(server, "tp @a " + player.getName().getString());
    }

    /** Убирает всех мобов в радиусе 48, кроме НПС-раздатчиков. @return сколько убрано */
    public static int killAllMobs(ServerWorld world, ServerPlayerEntity player) {
        Box box = player.getBoundingBox().expand(48.0);
        List<MobEntity> mobs = world.getEntitiesByClass(MobEntity.class, box,
                mob -> !Config.get().npcs.containsKey(mob.getUuidAsString()));
        for (MobEntity mob : mobs) {
            mob.discard();
        }
        return mobs.size();
    }

    /** Подсвечивает всех мобов в радиусе 48 на минуту. @return сколько мобов подсвечено */
    public static int glowMobs(ServerWorld world, ServerPlayerEntity player) {
        Box box = player.getBoundingBox().expand(48.0);
        List<MobEntity> mobs = world.getEntitiesByClass(MobEntity.class, box, mob -> true);
        for (MobEntity mob : mobs) {
            mob.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 1200));
        }
        return mobs.size();
    }

    /** Подбрасывает мобов в радиусе 32 в воздух (левитация на 5 секунд). @return сколько мобов подброшено */
    public static int launchMobs(ServerWorld world, ServerPlayerEntity player) {
        Box box = player.getBoundingBox().expand(32.0);
        List<MobEntity> mobs = world.getEntitiesByClass(MobEntity.class, box,
                mob -> !Config.get().npcs.containsKey(mob.getUuidAsString()));
        for (MobEntity mob : mobs) {
            mob.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 100, 3));
        }
        return mobs.size();
    }

    /** Лечит всех мобов в радиусе 32. @return сколько мобов вылечено */
    public static int healMobs(ServerWorld world, ServerPlayerEntity player) {
        Box box = player.getBoundingBox().expand(32.0);
        List<MobEntity> mobs = world.getEntitiesByClass(MobEntity.class, box, mob -> true);
        for (MobEntity mob : mobs) {
            mob.setHealth(mob.getMaxHealth());
        }
        return mobs.size();
    }

    /** Координаты и направление взгляда. */
    public static String coords(ServerPlayerEntity player) {
        BlockPos pos = player.getBlockPos();
        return "X: " + pos.getX() + "  Y: " + pos.getY() + "  Z: " + pos.getZ()
                + "  (смотрите: " + player.getHorizontalFacing().asString() + ")";
    }

    // ---------- параметры игрока (атрибуты) ----------

    public static final double[] SIZES = {1.0, 2.0, 4.0, 0.5, 0.25};
    public static final int[] WALK = {1, 2, 3, 5, 8};
    public static final int[] HEALTH = {20, 40, 100, 200};
    public static final double[] GRAVITY = {0.08, 0.04, 0.02, 0.16};
    public static final String[] GRAVITY_NAMES = {"обычная", "лунная", "почти невесомость", "тяжёлая"};

    public static String num(double value) {
        return value == Math.rint(value) ? String.valueOf((long) value) : String.valueOf(value);
    }

    /** Следующий размер игрока: 1 -> 2 -> 4 -> 0.5 -> 0.25 -> 1. */
    public static void nextSize(ServerPlayerEntity player, ToolSettings t) {
        t.size = (t.size + 1) % SIZES.length;
        var attribute = player.getAttributeInstance(EntityAttributes.SCALE);
        if (attribute != null) {
            attribute.setBaseValue(SIZES[t.size]);
        }
    }

    /** Следующая скорость ходьбы: x1 -> x2 -> x3 -> x5 -> x8 -> x1. */
    public static void nextWalk(ServerPlayerEntity player, ToolSettings t) {
        t.walk = (t.walk + 1) % WALK.length;
        var attribute = player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED);
        if (attribute != null) {
            attribute.setBaseValue(0.1 * WALK[t.walk]);
        }
    }

    /** Следующее максимальное здоровье: 20 -> 40 -> 100 -> 200 -> 20. Здоровье восстанавливается. */
    public static void nextHealth(ServerPlayerEntity player, ToolSettings t) {
        t.health = (t.health + 1) % HEALTH.length;
        var attribute = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (attribute != null) {
            attribute.setBaseValue(HEALTH[t.health]);
        }
        player.setHealth(player.getMaxHealth());
    }

    /** Следующая гравитация: обычная -> лунная -> почти невесомость -> тяжёлая. */
    public static void nextGravity(ServerPlayerEntity player, ToolSettings t) {
        t.gravity = (t.gravity + 1) % GRAVITY.length;
        var attribute = player.getAttributeInstance(EntityAttributes.GRAVITY);
        if (attribute != null) {
            attribute.setBaseValue(GRAVITY[t.gravity]);
        }
    }

    /** Возвращает размер, скорость, здоровье и гравитацию к обычным. */
    public static void resetAttributes(ServerPlayerEntity player, ToolSettings t) {
        t.size = 0;
        t.walk = 0;
        t.health = 0;
        t.gravity = 0;
        var scale = player.getAttributeInstance(EntityAttributes.SCALE);
        if (scale != null) {
            scale.setBaseValue(1.0);
        }
        var speed = player.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.setBaseValue(0.1);
        }
        var maxHealth = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(20.0);
        }
        var gravity = player.getAttributeInstance(EntityAttributes.GRAVITY);
        if (gravity != null) {
            gravity.setBaseValue(0.08);
        }
        player.setHealth(Math.min(player.getHealth(), player.getMaxHealth()));
    }

    // ---------- сохранённая точка ----------

    private static final Map<UUID, Vec3d> HOME = new HashMap<>();

    public static void setPoint(ServerPlayerEntity player) {
        HOME.put(player.getUuid(), new Vec3d(player.getX(), player.getY(), player.getZ()));
    }

    public static boolean goPoint(ServerPlayerEntity player) {
        Vec3d point = HOME.get(player.getUuid());
        if (point == null) {
            return false;
        }
        remember(player);
        player.requestTeleport(point.x, point.y, point.z);
        return true;
    }

    // ---------- развлечения ----------

    /** Дождь из 20 животных над точкой прицела. @return сколько появилось */
    public static int animalRain(ServerWorld world, ServerPlayerEntity player) {
        EntityType<?>[] types = {EntityType.CHICKEN, EntityType.PIG, EntityType.COW, EntityType.SHEEP, EntityType.RABBIT};
        Vec3d center = Targets.look(player);
        ThreadLocalRandom random = ThreadLocalRandom.current();
        int y = (int) center.y + 25;
        if (world.isOutOfHeightLimit(y)) {
            return 0;
        }
        int count = 0;
        for (int i = 0; i < 20; i++) {
            int x = (int) Math.floor(center.x + (random.nextDouble() * 2 - 1) * 6);
            int z = (int) Math.floor(center.z + (random.nextDouble() * 2 - 1) * 6);
            if (types[random.nextInt(types.length)].spawn(world, new BlockPos(x, y, z), SpawnReason.COMMAND) != null) {
                count++;
            }
        }
        return count;
    }

    private static List<HostileEntity> hostiles(ServerWorld world, ServerPlayerEntity player) {
        return world.getEntitiesByClass(HostileEntity.class, player.getBoundingBox().expand(32.0), mob -> true);
    }

    /** Бьёт молнией каждого враждебного моба в радиусе 32. @return сколько мобов поражено */
    public static int smiteMobs(ServerWorld world, ServerPlayerEntity player) {
        List<HostileEntity> mobs = hostiles(world, player);
        for (HostileEntity mob : mobs) {
            EntityType.LIGHTNING_BOLT.spawn(world, mob.getBlockPos(), SpawnReason.COMMAND);
        }
        return mobs.size();
    }

    /** Взрыв (без разрушения блоков) под каждым враждебным мобом в радиусе 32. Осторожно: урон получает и всё рядом. */
    public static int bombMobs(ServerWorld world, ServerPlayerEntity player) {
        List<HostileEntity> mobs = hostiles(world, player);
        for (HostileEntity mob : mobs) {
            Targets.explode(world, new Vec3d(mob.getX(), mob.getY(), mob.getZ()), 3.0, false, false);
        }
        return mobs.size();
    }

    /** Поджигает мобов в радиусе 32 на 10 секунд (НПС не трогает). */
    public static int burnMobs(ServerWorld world, ServerPlayerEntity player) {
        List<MobEntity> mobs = world.getEntitiesByClass(MobEntity.class, player.getBoundingBox().expand(32.0),
                mob -> !Config.get().npcs.containsKey(mob.getUuidAsString()));
        for (MobEntity mob : mobs) {
            mob.setOnFireFor(10);
        }
        return mobs.size();
    }

    /** Притягивает мобов в радиусе 32 к игроку (НПС не трогает). */
    public static int pullMobs(ServerWorld world, ServerPlayerEntity player) {
        List<MobEntity> mobs = world.getEntitiesByClass(MobEntity.class, player.getBoundingBox().expand(32.0),
                mob -> !Config.get().npcs.containsKey(mob.getUuidAsString()));
        for (MobEntity mob : mobs) {
            mob.setPosition(player.getX(), player.getY(), player.getZ());
        }
        return mobs.size();
    }

    /** Выдаёт копию предмета из руки всем игрокам онлайн. @return сколько игроков получили, -1 если рука пуста */
    public static int giveAll(MinecraftServer server, ServerPlayerEntity player) {
        ItemStack held = player.getMainHandStack();
        if (held.isEmpty()) {
            return -1;
        }
        List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();
        for (ServerPlayerEntity p : players) {
            p.getInventory().offerOrDrop(held.copy());
        }
        return players.size();
    }

    /** Объявление всем игрокам в чат. */
    public static void announce(MinecraftServer server, String message) {
        server.getPlayerManager().broadcast(Text.literal("[Админ] " + message), false);
    }
}
