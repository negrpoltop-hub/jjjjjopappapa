package com.adminmod.client;

import com.adminmod.OpenPanelPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import org.lwjgl.glfw.GLFW;

/**
 * Клиентская часть (нужна только админам): горячая клавиша Ctrl+Shift+Ц открывает админ-панель.
 * Ц — это клавиша W (в раскладке ЙЦУКЕН на ней буква Ц), поэтому сочетание работает в любой раскладке.
 */
@Environment(EnvType.CLIENT)
public class AdminModClient implements ClientModInitializer {
    /** Физическая клавиша сочетания. Для другой клавиши замените, например, на GLFW.GLFW_KEY_C. */
    private static final int HOTKEY = GLFW.GLFW_KEY_W;

    private static boolean wasDown = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                wasDown = false;
                return;
            }
            long window = client.getWindow().getHandle();
            boolean ctrl = pressed(window, GLFW.GLFW_KEY_LEFT_CONTROL) || pressed(window, GLFW.GLFW_KEY_RIGHT_CONTROL);
            boolean shift = pressed(window, GLFW.GLFW_KEY_LEFT_SHIFT) || pressed(window, GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean down = ctrl && shift && pressed(window, HOTKEY);
            // срабатывает один раз на нажатие и только когда нет открытого окна/чата
            if (down && !wasDown && client.currentScreen == null
                    && ClientPlayNetworking.canSend(OpenPanelPayload.ID)) {
                ClientPlayNetworking.send(new OpenPanelPayload());
            }
            wasDown = down;
        });
    }

    private static boolean pressed(long window, int key) {
        return GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
    }
}
