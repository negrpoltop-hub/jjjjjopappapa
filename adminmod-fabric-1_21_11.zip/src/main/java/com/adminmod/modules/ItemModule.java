package com.adminmod.modules;

import com.adminmod.Actions;
import com.adminmod.AdminMod;
import com.adminmod.Config;
import com.adminmod.Module;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

public class ItemModule implements Module {
    @Override
    public String id() {
        return "items";
    }

    @Override
    public void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        // /enchantmax         -> уровень по умолчанию (0 = ванильный максимум)
        // /enchantmax <1-255> -> ровно этот уровень для всех подходящих чар
        dispatcher.register(CommandManager.literal("enchantmax")
                .requires(AdminMod::isAdminSource)
                .executes(ctx -> enchant(ctx.getSource(), Config.get().defaultEnchantLevel))
                .then(CommandManager.argument("level", IntegerArgumentType.integer(0, 255))
                        .executes(ctx -> enchant(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "level")))));

        dispatcher.register(CommandManager.literal("repair")
                .requires(AdminMod::isAdminSource)
                .executes(ctx -> {
                    ServerCommandSource source = ctx.getSource();
                    boolean ok = Actions.repair(source.getPlayerOrThrow().getMainHandStack());
                    source.sendFeedback(() -> Text.literal(ok ? "Предмет починен" : "Этот предмет нельзя починить"), false);
                    return ok ? 1 : 0;
                }));
    }

    private static int enchant(ServerCommandSource source, int level) throws CommandSyntaxException {
        ItemStack held = source.getPlayerOrThrow().getMainHandStack();
        if (held.isEmpty()) {
            source.sendFeedback(() -> Text.literal("Возьмите предмет в руку"), false);
            return 0;
        }
        int count = Actions.enchantMax(source.getServer(), held, level);
        source.sendFeedback(() -> Text.literal("Наложено зачарований: " + count), false);
        return count;
    }
}
