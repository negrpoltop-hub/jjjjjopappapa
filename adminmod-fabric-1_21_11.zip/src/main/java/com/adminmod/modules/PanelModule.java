package com.adminmod.modules;

import com.adminmod.AdminMod;
import com.adminmod.Module;
import com.adminmod.PanelHandler;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;

public class PanelModule implements Module {
    @Override
    public String id() {
        return "panel";
    }

    @Override
    public void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("admin")
                .requires(AdminMod::isAdminSource)
                .executes(ctx -> {
                    ServerCommandSource source = ctx.getSource();
                    ServerPlayerEntity player = source.getPlayerOrThrow();
                    PanelHandler.open(player, source.getServer(), source.getWorld());
                    return 1;
                }));
    }
}
