package com.adminmod.modules;

import com.adminmod.Module;
import com.adminmod.chaos.BombManager;
import com.adminmod.chaos.MeteorManager;
import com.adminmod.chaos.Profiles;
import com.adminmod.chaos.Targets;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.ServerCommandSource;

/** Настраиваемые «разрушительные» функции: метеоритный дождь и бомба из руки. */
public class ChaosModule implements Module {
    @Override
    public String id() {
        return "chaos";
    }

    @Override
    public void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        PlayerModule.simple(dispatcher, "meteor", (source, player) -> {
            MeteorManager.start(source.getWorld(), Targets.look(player), Profiles.meteor(player.getUuid()));
            return "Метеоритный дождь запущен";
        });
        PlayerModule.simple(dispatcher, "bombwand", (source, player) -> {
            BombManager.giveWand(player);
            return "Жезл бомб выдан: правый клик запускает бомбу туда, куда вы смотрите";
        });
    }
}
