package com.adminmod.modules;

import com.adminmod.Actions;
import com.adminmod.AdminMod;
import com.adminmod.Module;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.function.BiFunction;

public class PlayerModule implements Module {
    @Override
    public String id() {
        return "player";
    }

    @Override
    public void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        simple(dispatcher, "heal", (s, p) -> {
            Actions.heal(p);
            return "Здоровье восстановлено";
        });
        simple(dispatcher, "feed", (s, p) -> {
            Actions.feed(p);
            return "Голод утолён";
        });
        simple(dispatcher, "fly", (s, p) -> Actions.toggleFly(p) ? "Полёт включён" : "Полёт выключен");
        simple(dispatcher, "god", (s, p) -> Actions.toggleGod(p) ? "Бессмертие включено" : "Бессмертие выключено");
        simple(dispatcher, "nightvision", (s, p) ->
                Actions.toggleEffect(p, StatusEffects.NIGHT_VISION, 0) ? "Ночное зрение включено" : "Ночное зрение выключено");
        simple(dispatcher, "speed", (s, p) ->
                Actions.toggleEffect(p, StatusEffects.SPEED, 2) ? "Скорость включена" : "Скорость выключена");
        simple(dispatcher, "cleareffects", (s, p) -> {
            Actions.clearEffects(p);
            return "Эффекты сняты";
        });
        simple(dispatcher, "smite", (s, p) -> {
            Actions.smite(s.getWorld(), p);
            return "Молния!";
        });
        simple(dispatcher, "clearmobs", (s, p) -> "Убрано мобов: " + Actions.clearMobs(s.getWorld(), p));
    }

    static void simple(CommandDispatcher<ServerCommandSource> dispatcher, String name,
                       BiFunction<ServerCommandSource, ServerPlayerEntity, String> action) {
        dispatcher.register(CommandManager.literal(name)
                .requires(AdminMod::isAdminSource)
                .executes(ctx -> {
                    ServerCommandSource source = ctx.getSource();
                    String message = action.apply(source, source.getPlayerOrThrow());
                    source.sendFeedback(() -> Text.literal(message), false);
                    return 1;
                }));
    }
}
