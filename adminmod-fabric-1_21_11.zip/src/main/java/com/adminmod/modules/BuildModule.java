package com.adminmod.modules;

import com.adminmod.AdminMod;
import com.adminmod.Module;
import com.adminmod.Tools;
import com.adminmod.chaos.DestroyManager;
import com.adminmod.chaos.DestroySettings;
import com.adminmod.chaos.Profiles;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Разрушение блоков, разлом, откат и прочие инструменты админа. */
public class BuildModule implements Module {
    @Override
    public String id() {
        return "tools";
    }

    @Override
    public void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        // /destroy [радиус]
        dispatcher.register(CommandManager.literal("destroy")
                .requires(AdminMod::isAdminSource)
                .executes(ctx -> destroy(ctx.getSource(), -1))
                .then(CommandManager.argument("radius", IntegerArgumentType.integer(1, 32))
                        .executes(ctx -> destroy(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "radius")))));

        // /rift [радиус] [длина] [глубина]
        dispatcher.register(CommandManager.literal("rift")
                .requires(AdminMod::isAdminSource)
                .executes(ctx -> rift(ctx.getSource(), -1, -1, -1))
                .then(CommandManager.argument("radius", IntegerArgumentType.integer(1, 16))
                        .executes(ctx -> rift(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "radius"), -1, -1))
                        .then(CommandManager.argument("length", IntegerArgumentType.integer(5, 128))
                                .executes(ctx -> rift(ctx.getSource(),
                                        IntegerArgumentType.getInteger(ctx, "radius"),
                                        IntegerArgumentType.getInteger(ctx, "length"), -1))
                                .then(CommandManager.argument("depth", IntegerArgumentType.integer(3, 64))
                                        .executes(ctx -> rift(ctx.getSource(),
                                                IntegerArgumentType.getInteger(ctx, "radius"),
                                                IntegerArgumentType.getInteger(ctx, "length"),
                                                IntegerArgumentType.getInteger(ctx, "depth")))))));

        PlayerModule.simple(dispatcher, "undo", (s, p) -> {
            int count = DestroyManager.undo(p.getUuid());
            return count > 0 ? "Возвращаю блоков: " + count : "Откатывать нечего";
        });
        PlayerModule.simple(dispatcher, "cancelbuild", (s, p) ->
                "Отменено задач: " + DestroyManager.cancel(p.getUuid()));

        PlayerModule.simple(dispatcher, "tptarget", (s, p) ->
                Tools.teleportToTarget(p) ? "Телепорт к прицелу" : "Смотрите на блок");
        PlayerModule.simple(dispatcher, "top", (s, p) -> {
            Tools.teleportToSurface(s.getWorld(), p);
            return "Вы на поверхности";
        });
        PlayerModule.simple(dispatcher, "back", (s, p) ->
                Tools.teleportBack(p) ? "Вы вернулись" : "Некуда возвращаться");
        PlayerModule.simple(dispatcher, "gm", (s, p) -> "Режим игры: " + Tools.cycleGameMode(p));
        PlayerModule.simple(dispatcher, "ec", (s, p) -> {
            Tools.openEnderChest(p);
            return "Эндер-сундук";
        });
        PlayerModule.simple(dispatcher, "clearitems", (s, p) ->
                "Убрано предметов: " + Tools.clearItems(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "magnet", (s, p) ->
                "Притянуто предметов: " + Tools.magnet(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "kit", (s, p) ->
                "Выдано предметов: " + Tools.giveKit(s.getServer(), p, 0));
        PlayerModule.simple(dispatcher, "healall", (s, p) ->
                "Вылечено игроков: " + Tools.healAll(s.getServer()));
        PlayerModule.simple(dispatcher, "storm", (s, p) -> {
            Tools.lightningStorm(s.getWorld(), p);
            return "Гроза!";
        });
        PlayerModule.simple(dispatcher, "megaboom", (s, p) -> {
            Tools.megaExplosion(s.getWorld(), p);
            return "Взрыв!";
        });
        PlayerModule.simple(dispatcher, "day", (s, p) -> {
            Tools.run(s.getServer(), "time set day");
            return "День";
        });
        PlayerModule.simple(dispatcher, "night", (s, p) -> {
            Tools.run(s.getServer(), "time set night");
            return "Ночь";
        });
        PlayerModule.simple(dispatcher, "platform", (s, p) ->
                "Платформа построена, блоков: " + Tools.buildPlatform(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "bunker", (s, p) ->
                "Бункер построен, блоков изменено: " + Tools.buildBunker(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "buildkit", (s, p) ->
                "Выдан набор строителя: " + Tools.giveBuilderKit(p) + " видов");
        PlayerModule.simple(dispatcher, "guards", (s, p) ->
                "Призвано охранников: " + Tools.summonGuards(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "dup", (s, p) ->
                Tools.duplicateHeld(p) ? "Предмет скопирован" : "Возьмите предмет в руку");
        PlayerModule.simple(dispatcher, "repairall", (s, p) ->
                "Починено предметов: " + Tools.repairAll(p));
        PlayerModule.simple(dispatcher, "tpall", (s, p) -> {
            Tools.bringAll(s.getServer(), p);
            return "Все игроки телепортированы к вам";
        });
        PlayerModule.simple(dispatcher, "killmobs", (s, p) ->
                "Убрано мобов: " + Tools.killAllMobs(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "glowmobs", (s, p) ->
                "Подсвечено мобов: " + Tools.glowMobs(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "launchmobs", (s, p) ->
                "Подброшено мобов: " + Tools.launchMobs(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "healmobs", (s, p) ->
                "Вылечено мобов: " + Tools.healMobs(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "coords", (s, p) -> Tools.coords(p));
        PlayerModule.simple(dispatcher, "size", (s, p) -> {
            var t = Profiles.tools(p.getUuid());
            Tools.nextSize(p, t);
            return "Размер: x" + Tools.num(Tools.SIZES[t.size]);
        });
        PlayerModule.simple(dispatcher, "walk", (s, p) -> {
            var t = Profiles.tools(p.getUuid());
            Tools.nextWalk(p, t);
            return "Скорость ходьбы: x" + Tools.WALK[t.walk];
        });
        PlayerModule.simple(dispatcher, "hp", (s, p) -> {
            var t = Profiles.tools(p.getUuid());
            Tools.nextHealth(p, t);
            return "Максимум здоровья: " + Tools.HEALTH[t.health];
        });
        PlayerModule.simple(dispatcher, "gravity", (s, p) -> {
            var t = Profiles.tools(p.getUuid());
            Tools.nextGravity(p, t);
            return "Гравитация: " + Tools.GRAVITY_NAMES[t.gravity];
        });
        PlayerModule.simple(dispatcher, "normal", (s, p) -> {
            Tools.resetAttributes(p, Profiles.tools(p.getUuid()));
            return "Размер, скорость, здоровье и гравитация сброшены";
        });
        PlayerModule.simple(dispatcher, "setpoint", (s, p) -> {
            Tools.setPoint(p);
            return "Точка сохранена";
        });
        PlayerModule.simple(dispatcher, "gopoint", (s, p) ->
                Tools.goPoint(p) ? "Телепорт на сохранённую точку" : "Точка не сохранена (/setpoint)");
        PlayerModule.simple(dispatcher, "animalrain", (s, p) ->
                "Упало животных: " + Tools.animalRain(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "smitemobs", (s, p) ->
                "Поражено мобов: " + Tools.smiteMobs(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "bombmobs", (s, p) ->
                "Взорвано мобов: " + Tools.bombMobs(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "burnmobs", (s, p) ->
                "Подожжено мобов: " + Tools.burnMobs(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "pullmobs", (s, p) ->
                "Притянуто мобов: " + Tools.pullMobs(s.getWorld(), p));
        PlayerModule.simple(dispatcher, "giveall", (s, p) -> {
            int count = Tools.giveAll(s.getServer(), p);
            return count < 0 ? "Возьмите предмет в руку" : "Предмет выдан игрокам: " + count;
        });
        dispatcher.register(CommandManager.literal("announce")
                .requires(AdminMod::isAdminSource)
                .then(CommandManager.argument("text", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            Tools.announce(ctx.getSource().getServer(), StringArgumentType.getString(ctx, "text"));
                            return 1;
                        })));
        PlayerModule.simple(dispatcher, "flyspeed", (s, p) -> {
            int level = Profiles.tools(p.getUuid()).flySpeed % 10 + 1;
            Profiles.tools(p.getUuid()).flySpeed = level;
            Tools.setFlySpeed(p, level);
            return "Скорость полёта: " + level;
        });
    }

    private static int destroy(ServerCommandSource source, int radius) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity player = source.getPlayerOrThrow();
        DestroySettings settings = Profiles.destroy(player.getUuid());
        if (radius > 0) {
            settings.radius = radius;
        }
        int count = DestroyManager.blast(player, source.getWorld(), settings);
        source.sendFeedback(() -> Text.literal(count < 0
                ? "Очередь разрушения полна, подождите" : "Разрушаю область, позиций: " + count), false);
        return 1;
    }

    private static int rift(ServerCommandSource source, int radius, int length, int depth)
            throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity player = source.getPlayerOrThrow();
        DestroySettings settings = Profiles.destroy(player.getUuid());
        if (radius > 0) {
            settings.riftRadius = radius;
        }
        if (length > 0) {
            settings.riftLength = length;
        }
        if (depth > 0) {
            settings.riftDepth = depth;
        }
        int count = DestroyManager.rift(player, source.getWorld(), settings);
        source.sendFeedback(() -> Text.literal(count < 0
                ? "Очередь разрушения полна, подождите" : "Открываю разлом, позиций: " + count), false);
        return 1;
    }
}
