package com.adminmod;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.ServerCommandSource;

/** Один модуль = группа функций. Чтобы добавить функции, создайте новый модуль и впишите его в ModuleManager. */
public interface Module {
    String id();

    void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher);
}
